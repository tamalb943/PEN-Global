import "dotenv/config";
import { PrismaClient } from "../app/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error("DATABASE_URL is missing");
}

const adapter = new PrismaPg({ connectionString });
const prisma = new PrismaClient({ adapter });

async function main() {
  console.log("Starting PEN Global database seeding...");

  // 1. PROGRAMMES
  const programmes = [
    {
      name: "Bachelor of Business Administration",
      code: "BBA",
      feeAmount: 250000,
    },
    {
      name: "Bachelor of Computer Science",
      code: "BCS",
      feeAmount: 300000,
    },
  ];

  const programmeRecords = [];

  for (const programme of programmes) {
    const record = await prisma.programme.upsert({
      where: { code: programme.code },
      update: programme,
      create: programme,
    });
    programmeRecords.push(record);
  }

  console.log("Programmes created.");

  // 2. STUDENTS
  const names = [
    "James Wilson", "Olivia Brown", "Noah Smith", "Emma Johnson",
    "Liam Davis", "Ava Miller", "William Garcia", "Sophia Martinez",
    "Benjamin Anderson", "Isabella Taylor", "Lucas Thomas",
    "Mia Robinson", "Henry Clark", "Charlotte Lewis", "Alexander Lee",
    "Amelia Walker", "Daniel Hall", "Harper Allen", "Matthew Young",
    "Evelyn King", "Michael Wright", "Abigail Scott", "David Green",
    "Emily Baker", "Joseph Adams", "Ella Nelson", "Samuel Hill",
    "Grace Campbell", "Jack Mitchell", "Lily Carter",
  ];

  const statuses = [
    "ENROLLED", "ENROLLED", "ENROLLED", "DEFERRED",
    "ENROLLED", "WITHDRAWN", "ENROLLED", "COMPLETED",
    "ENROLLED", "ENROLLED",
  ] as const;

  const students = [];

  for (let i = 0; i < names.length; i++) {
    const number = i + 1;
    const programme = programmeRecords[i % 2];

    const student = await prisma.student.upsert({
      where: { studentId: `SMS-2026-${String(number).padStart(4, "0")}` },
      update: {
        fullName: names[i],
        programmeId: programme.id,
      },
      create: {
        studentId: `SMS-2026-${String(number).padStart(4, "0")}`,
        fullName: names[i],
        email: `student${number}@example.com`,
        dateOfBirth: new Date(Date.UTC(2000 + (i % 6), i % 12, 10 + (i % 18))),
        academicYear: "2026/2027",
        enrolmentStatus: statuses[i % statuses.length],
        programmeId: programme.id,
      },
    });

    students.push(student);
  }

  console.log("30 students created.");

  // 3. FEES AND PAYMENTS
  const now = new Date("2026-11-03T12:00:00.000Z");

  for (let i = 0; i < students.length; i++) {
    const student = students[i];
    const programme = programmeRecords[i % 2];
    const totalAmount = Number(programme.feeAmount);

    const fee = await prisma.fee.upsert({
      where: { studentId: student.id },
      update: {
        totalAmount,
        dueDate: new Date(
          i % 4 === 0
            ? "2026-10-01T00:00:00.000Z"
            : "2026-12-15T00:00:00.000Z"
        ),
      },
      create: {
        studentId: student.id,
        totalAmount,
        dueDate: new Date(
          i % 4 === 0
            ? "2026-10-01T00:00:00.000Z"
            : "2026-12-15T00:00:00.000Z"
        ),
      },
    });

    const paymentAmount =
      i % 3 === 0 ? totalAmount :
      i % 3 === 1 ? totalAmount / 2 :
      0;

    if (paymentAmount > 0) {
      await prisma.payment.upsert({
        where: { referenceNumber: `SEED-PAY-${String(i + 1).padStart(4, "0")}` },
        update: {
          amount: paymentAmount,
          feeId: fee.id,
        },
        create: {
          feeId: fee.id,
          amount: paymentAmount,
          paymentDate: new Date("2026-10-15T10:00:00.000Z"),
          referenceNumber: `SEED-PAY-${String(i + 1).padStart(4, "0")}`,
        },
      });
    }

    const balance = totalAmount - paymentAmount;

    await prisma.fee.update({
      where: { id: fee.id },
      data: {
        status:
          balance === 0 ? "PAID" :
          paymentAmount > 0 ? "PARTIAL" : "UNPAID",
      },
    });
  }

  console.log("Fees and payment transactions created.");

  // 4. ASSESSMENTS
  const assessmentData = [
    {
      id: "seed-assessment-001",
      title: "Business Strategy Report",
      module: "Business Management",
      deadline: new Date("2026-12-15T23:59:00.000Z"),
    },
    {
      id: "seed-assessment-002",
      title: "Digital Marketing Analysis",
      module: "Marketing",
      deadline: new Date("2026-12-20T23:59:00.000Z"),
    },
    {
      id: "seed-assessment-003",
      title: "Database Design Project",
      module: "Database Systems",
      deadline: new Date("2026-12-22T23:59:00.000Z"),
    },
    {
      id: "seed-assessment-004",
      title: "Software Development Report",
      module: "Software Engineering",
      deadline: new Date("2026-12-25T23:59:00.000Z"),
    },
    {
      id: "seed-assessment-005",
      title: "Research and Innovation",
      module: "Professional Studies",
      deadline: new Date("2026-10-15T23:59:00.000Z"),
    },
  ];

  const assessments = [];

  for (const assessment of assessmentData) {
    const record = await prisma.assessment.upsert({
      where: { id: assessment.id },
      update: assessment,
      create: assessment,
    });
    assessments.push(record);
  }

  console.log("5 assessments created.");

  // 5. SUBMISSIONS
  for (let i = 0; i < 20; i++) {
    const student = students[i];
    const assessment = assessments[i % assessments.length];
    const submittedAt = new Date(
      i % 5 === 4
        ? "2026-10-20T10:00:00.000Z"
        : "2026-11-01T10:00:00.000Z"
    );

    await prisma.submission.upsert({
      where: {
        studentId_assessmentId: {
          studentId: student.id,
          assessmentId: assessment.id,
        },
      },
      update: {
        fileName: `student-${i + 1}-assignment.pdf`,
        fileUrl: `https://example.com/submissions/student-${i + 1}.pdf`,
        submittedAt,
        isLate: submittedAt > assessment.deadline,
      },
      create: {
        studentId: student.id,
        assessmentId: assessment.id,
        fileName: `student-${i + 1}-assignment.pdf`,
        fileUrl: `https://example.com/submissions/student-${i + 1}.pdf`,
        submittedAt,
        isLate: submittedAt > assessment.deadline,
      },
    });
  }

  console.log("20 submissions created.");

  // 6. GRADES
  const scores = [35, 45, 55, 62, 68, 72, 78, 85, 91, 96];

  for (let i = 0; i < 20; i++) {
    const student = students[i];
    const assessment = assessments[i % assessments.length];
    const score = scores[i % scores.length];

    await prisma.grade.upsert({
      where: {
        studentId_assessmentId: {
          studentId: student.id,
          assessmentId: assessment.id,
        },
      },
      update: {
        score,
        isPublished: i % 2 === 0,
      },
      create: {
        studentId: student.id,
        assessmentId: assessment.id,
        score,
        isPublished: i % 2 === 0,
      },
    });
  }

  console.log("20 grades created.");

  // 7. STUDENT ID COUNTER
  await prisma.studentIdCounter.upsert({
    where: { year: 2026 },
    update: { lastNumber: Math.max(30, students.length) },
    create: { year: 2026, lastNumber: 30 },
  });

  console.log("Student ID counter updated.");
  console.log("PEN Global database seeding completed.");
}

main()
  .catch((error) => {
    console.error("Seeding failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
