
"use client";

import { useEffect, useMemo, useState } from "react";

type Student = {
  id: string;
  studentId: string;
  fullName: string;
  email: string;
  academicYear: string;
  enrolmentStatus: string;
  programme: {
    id: string;
    name: string;
    code: string;
  };
};

export default function StudentsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [programme, setProgramme] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
  async function loadStudents() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/students", {
        cache: "no-store",
      });

      const result = await response.json();

      console.log("Students API result:", result);

      if (!response.ok || !result.success) {
        throw new Error(result.message || "Unable to load students.");
      }

      setStudents(Array.isArray(result.data) ? result.data : []);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Something went wrong."
      );
    } finally {
      setLoading(false);
    }
  }

  loadStudents();
}, []);

  const programmes = Array.from(
    new Map(
      students.map((student) => [
        student.programme.id,
        student.programme,
      ])
    ).values()
  );

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      const matchesSearch =
        student.fullName.toLowerCase().includes(search.toLowerCase()) ||
        student.studentId.toLowerCase().includes(search.toLowerCase());

      const matchesProgramme =
        !programme || student.programme.id === programme;

      const matchesStatus =
        !status || student.enrolmentStatus === status;

      return matchesSearch && matchesProgramme && matchesStatus;
    });
  }, [students, search, programme, status]);

  return (
    <main className="min-h-screen bg-slate-50 px-6 py-10">
      <div className="mx-auto max-w-7xl">
        <p className="text-sm font-medium text-emerald-700">
          Registry Management
        </p>

        <div className="mt-2 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">
              Student Records
            </h1>
            <p className="mt-1 text-sm text-slate-500">
              Manage and search registered students.
            </p>
          </div>

          <span className="rounded-lg bg-emerald-600 px-5 py-3 text-sm font-semibold text-white">
            {students.length} Students
          </span>
        </div>

        <section className="mt-8 grid gap-4 rounded-xl border border-slate-200 bg-white p-5 md:grid-cols-3">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name or Student ID..."
            className="rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-emerald-600"
          />

          <select
            value={programme}
            onChange={(e) => setProgramme(e.target.value)}
            className="rounded-lg border border-slate-300 px-4 py-3 text-sm"
          >
            <option value="">All Programmes</option>
            {programmes.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name}
              </option>
            ))}
          </select>

          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="rounded-lg border border-slate-300 px-4 py-3 text-sm"
          >
            <option value="">All Statuses</option>
            {["ENROLLED", "DEFERRED", "WITHDRAWN", "COMPLETED"].map(
              (item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              )
            )}
          </select>
        </section>

        <section className="mt-6 overflow-hidden rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 p-5">
            <h2 className="font-semibold text-slate-800">
              Registered Students
            </h2>
            <span className="text-sm text-slate-500">
              {filteredStudents.length} records
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-5 py-4">Student ID</th>
                  <th className="px-5 py-4">Student Name</th>
                  <th className="px-5 py-4">Email</th>
                  <th className="px-5 py-4">Programme</th>
                  <th className="px-5 py-4">Academic Year</th>
                  <th className="px-5 py-4">Status</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td colSpan={6} className="px-5 py-12 text-center">
                      Loading student records...
                    </td>
                  </tr>
                ) : error ? (
                  <tr>
                    <td colSpan={6} className="px-5 py-12 text-center text-red-600">
                      {error}
                    </td>
                  </tr>
                ) : filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-5 py-12 text-center text-slate-500">
                      No matching student records found.
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((student) => (
                    <tr key={student.id}>
                      <td className="px-5 py-4 font-medium text-emerald-700">
                        {student.studentId}
                      </td>
                      <td className="px-5 py-4 font-medium text-slate-800">
                        {student.fullName}
                      </td>
                      <td className="px-5 py-4 text-slate-600">
                        {student.email}
                      </td>
                      <td className="px-5 py-4 text-slate-600">
                        {student.programme.name}
                      </td>
                      <td className="px-5 py-4 text-slate-600">
                        {student.academicYear}
                      </td>
                      <td className="px-5 py-4">
                        <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700">
                          {student.enrolmentStatus}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>

        <footer className="mt-6 text-xs text-slate-400">
          PEN Global · Student Management System
        </footer>
      </div>
    </main>
  );
}
