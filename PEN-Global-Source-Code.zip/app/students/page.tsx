
"use client";

import { useEffect, useState } from "react";

type Programme = {
  id: string;
  name: string;
  code: string;
};

type Student = {
  id: string;
  studentId: string;
  fullName: string;
  email: string;
  academicYear: string;
  enrolmentStatus: string;
  programme: Programme;
};

export default function StudentsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [programmes, setProgrammes] = useState<Programme[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  async function loadData() {
    try {
      setLoading(true);
      setError("");

      const [studentsResponse, programmesResponse] = await Promise.all([
        fetch("/api/students", { cache: "no-store" }),
        fetch("/api/programmes", { cache: "no-store" }),
      ]);

      const studentsResult = await studentsResponse.json();
      const programmesResult = await programmesResponse.json();

      if (!studentsResponse.ok || !studentsResult.success) {
        throw new Error(studentsResult.message || "Unable to load students.");
      }

      if (!programmesResponse.ok || !programmesResult.success) {
        throw new Error(programmesResult.message || "Unable to load programmes.");
      }

      setStudents(studentsResult.data || []);
      setProgrammes(programmesResult.data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.fullName.toLowerCase().includes(search.toLowerCase()) ||
      student.studentId.toLowerCase().includes(search.toLowerCase());

    const matchesStatus =
      !status || student.enrolmentStatus === status;

    return matchesSearch && matchesStatus;
  });

  return (
    <main className="min-h-screen bg-slate-50 p-6 md:p-10">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-emerald-700">
              Registry Management
            </p>
            <h1 className="mt-2 text-3xl font-bold text-slate-800">
              Student Records
            </h1>
            <p className="mt-2 text-slate-500">
              Manage and search registered students.
            </p>
          </div>

          <div className="rounded-lg bg-emerald-600 px-6 py-3 font-semibold text-white">
            {students.length} Students
          </div>
        </div>

        <section className="mb-6 grid gap-4 rounded-xl border border-slate-200 bg-white p-5 md:grid-cols-2">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name or Student ID..."
            className="rounded-lg border border-slate-300 px-4 py-3 text-black outline-none focus:border-emerald-500"
          />

          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="rounded-lg border border-slate-300 px-4 py-3 text-black outline-none focus:border-emerald-500"
          >
            <option value="">All Statuses</option>
            <option value="ENROLLED">Enrolled</option>
            <option value="DEFERRED">Deferred</option>
            <option value="WITHDRAWN">Withdrawn</option>
            <option value="COMPLETED">Completed</option>
          </select>
        </section>

        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 p-5">
            <h2 className="font-semibold text-slate-800">
              Registered Students
            </h2>
            <span className="text-sm text-slate-500">
              {filteredStudents.length} records
            </span>
          </div>

          {loading ? (
            <p className="p-12 text-center text-slate-500">
              Loading student records...
            </p>
          ) : error ? (
            <div className="p-8 text-center text-red-600">
              {error}
              <button
                onClick={loadData}
                className="ml-3 font-semibold underline"
              >
                Retry
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-black text-sm">
                <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                  <tr>
                    <th className="p-4">Student ID</th>
                    <th className="p-4">Student Name</th>
                    <th className="p-4">Email</th>
                    <th className="p-4">Programme</th>
                    <th className="p-4">Academic Year</th>
                    <th className="p-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredStudents.map((student) => (
                    <tr key={student.id}>
                      <td className="p-4 font-medium text-emerald-700">
                        {student.studentId}
                      </td>
                      <td className="p-4 font-medium text-slate-800">
                        {student.fullName}
                      </td>
                      <td className="p-4 text-slate-600">
                        {student.email}
                      </td>
                      <td className="p-4 text-slate-600">
                        {student.programme?.name || "—"}
                      </td>
                      <td className="p-4 text-slate-600">
                        {student.academicYear}
                      </td>
                      <td className="p-4 text-slate-800">
                        {student.enrolmentStatus}
                      </td>
                    </tr>
                  ))}

                  {filteredStudents.length === 0 && (
                    <tr>
                      <td
                        colSpan={6}
                        className="p-12 text-center text-slate-500"
                      >
                        No matching student records found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <footer className="mt-6 text-xs text-slate-400">
          PEN Global · Student Management System
        </footer>
      </div>
    </main>
  );
}
