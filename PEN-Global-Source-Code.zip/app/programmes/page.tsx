
"use client";

import { useEffect, useState } from "react";

type Programme = {
  id: string;
  name: string;
  code: string;
  feeAmount: number | string;
};

export default function ProgrammesPage() {
  const [programmes, setProgrammes] = useState<Programme[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [form, setForm] = useState({
    name: "",
    code: "",
    feeAmount: "",
  });

  // Load programmes from PostgreSQL through the API
  async function loadProgrammes() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/programmes", {
        cache: "no-store",
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(
          result.message || result.error || "Unable to load programmes."
        );
      }

      setProgrammes(result.data);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Something went wrong."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadProgrammes();
  }, []);

  // Create a new programme
  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    setSaving(true);
    setError("");
    setSuccess("");

    try {
      const response = await fetch("/api/programmes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: form.name.trim(),
          code: form.code.trim().toUpperCase(),
          feeAmount: Number(form.feeAmount),
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(
          result.message || result.error || "Unable to create programme."
        );
      }

      setForm({
        name: "",
        code: "",
        feeAmount: "",
      });

      setSuccess("Programme created successfully.");

      await loadProgrammes();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Something went wrong."
      );
    } finally {
      setSaving(false);
    }
  }

  // Format fees in Bangladeshi Taka
  function formatCurrency(amount: number | string) {
    return new Intl.NumberFormat("en-BD", {
      style: "currency",
      currency: "BDT",
      maximumFractionDigits: 2,
    }).format(Number(amount));
  }

  return (
    <main className="min-h-screen bg-slate-50 p-6 md:p-10">
      <div className="mx-auto max-w-7xl space-y-8">

        {/* Page Header */}
        <header>
          <p className="text-sm font-medium text-emerald-700">
            Registry Management
          </p>

          <h1 className="mt-2 text-3xl font-bold text-slate-800">
            Programmes
          </h1>

          <p className="mt-2 text-slate-500">
            Manage academic programmes, programme codes and tuition fees.
          </p>
        </header>

        {/* Programme Statistics */}
        <section className="grid gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-slate-500">
              Total Programmes
            </p>

            <p className="mt-3 text-3xl font-bold text-slate-800">
              {loading ? "—" : programmes.length}
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-slate-500">
              Average Tuition Fee
            </p>

            <p className="mt-3 text-3xl font-bold text-slate-800">
              {loading || programmes.length === 0
                ? "—"
                : formatCurrency(
                    programmes.reduce(
                      (total, programme) =>
                        total + Number(programme.feeAmount),
                      0
                    ) / programmes.length
                  )}
            </p>
          </div>
        </section>

        {/* Add Programme Form */}
        <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-800">
            Add New Programme
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Enter the academic programme details below.
          </p>

          <form
            onSubmit={handleSubmit}
            className="mt-6 grid gap-5 md:grid-cols-3"
          >
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Programme Name
              </label>

              <input
                type="text"
                required
                value={form.name}
                onChange={(e) =>
                  setForm({ ...form, name: e.target.value })
                }
                placeholder="Bachelor of Business Administration"
                className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm text-black outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Programme Code
              </label>

              <input
                type="text"
                required
                value={form.code}
                onChange={(e) =>
                  setForm({ ...form, code: e.target.value })
                }
                placeholder="BBA-2026"
                className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm text-black uppercase outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Tuition Fee (BDT)
              </label>

              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={form.feeAmount}
                onChange={(e) =>
                  setForm({ ...form, feeAmount: e.target.value })
                }
                placeholder="250000"
                className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm text-black outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100"
              />
            </div>

            <div className="md:col-span-3">
              <button
                type="submit"
                disabled={saving}
                className="rounded-lg bg-emerald-600 px-6 py-3 text-sm font-semibold text-white transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {saving ? "Saving Programme..." : "+ Add Programme"}
              </button>
            </div>
          </form>

          {error && (
            <div className="mt-5 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
              {error}
            </div>
          )}

          {success && (
            <div className="mt-5 rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">
              {success}
            </div>
          )}
        </section>

        {/* Programme Records */}
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">

          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-6">
            <div>
              <h2 className="font-semibold text-slate-800">
                Registered Programmes
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                {programmes.length} programmes registered in the database
              </p>
            </div>

            <button
              onClick={loadProgrammes}
              disabled={loading}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50"
            >
              {loading ? "Refreshing..." : "Refresh"}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-6 py-4">Programme Name</th>
                  <th className="px-6 py-4">Programme Code</th>
                  <th className="px-6 py-4">Tuition Fee</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td
                      colSpan={3}
                      className="px-6 py-10 text-center text-slate-500"
                    >
                      Loading programmes...
                    </td>
                  </tr>
                ) : programmes.length === 0 ? (
                  <tr>
                    <td
                      colSpan={3}
                      className="px-6 py-10 text-center text-slate-500"
                    >
                      No programmes found.
                    </td>
                  </tr>
                ) : (
                  programmes.map((programme) => (
                    <tr
                      key={programme.id}
                      className="transition hover:bg-slate-50"
                    >
                      <td className="px-6 py-4 font-medium text-slate-800">
                        {programme.name}
                      </td>

                      <td className="px-6 py-4 text-slate-600">
                        <span className="rounded-md bg-slate-100 px-2 py-1 font-mono text-xs">
                          {programme.code}
                        </span>
                      </td>

                      <td className="px-6 py-4 font-semibold text-slate-800">
                        {formatCurrency(programme.feeAmount)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-slate-200 pt-5 text-xs text-slate-400">
          PEN Global · Student Management System · Programme Registry
        </footer>

      </div>
    </main>
  );
}
