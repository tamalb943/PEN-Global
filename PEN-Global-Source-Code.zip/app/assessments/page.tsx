
"use client";

import { useEffect, useState } from "react";

type Assessment = {
  id: string;
  title: string;
  module: string;
  deadline: string;
  createdAt: string;
  _count?: {
    submissions: number;
  };
};

export default function AssessmentsPage() {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [form, setForm] = useState({
    title: "",
    module: "",
    deadline: "",
  });

  async function loadAssessments() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/assessments", {
        cache: "no-store",
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(
          result.message || "Failed to load assessments."
        );
      }

      setAssessments(result.data);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Unable to load assessments."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAssessments();
  }, []);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    setSaving(true);
    setError("");
    setSuccess("");

    try {
      const response = await fetch("/api/assessments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: form.title.trim(),
          module: form.module.trim(),
          deadline: new Date(form.deadline).toISOString(),
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(
          result.message || "Failed to create assessment."
        );
      }

      setSuccess("Assessment created successfully.");

      setForm({
        title: "",
        module: "",
        deadline: "",
      });

      await loadAssessments();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Unable to create assessment."
      );
    } finally {
      setSaving(false);
    }
  }

  const now = new Date();

  const openAssessments = assessments.filter(
    (assessment) => new Date(assessment.deadline) >= now
  );

  const closedAssessments = assessments.filter(
    (assessment) => new Date(assessment.deadline) < now
  );

  function formatDate(date: string) {
    return new Date(date).toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  return (
    <main className="min-h-screen bg-slate-50 p-6 md:p-10">
      <div className="mx-auto max-w-7xl space-y-8">

        {/* Header */}
        <header>
          <p className="text-sm font-medium text-emerald-700">
            Registry Management
          </p>

          <h1 className="mt-2 text-3xl font-bold text-slate-800">
            Assessments
          </h1>

          <p className="mt-2 text-slate-500">
            Create academic assessments, manage deadlines and monitor student submissions.
          </p>
        </header>

        {/* Statistics */}
        <section className="grid gap-4 sm:grid-cols-3">
          {[
            {
              title: "Total Assessments",
              value: assessments.length,
            },
            {
              title: "Open Assessments",
              value: openAssessments.length,
            },
            {
              title: "Past Deadline",
              value: closedAssessments.length,
            },
          ].map((item) => (
            <div
              key={item.title}
              className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
            >
              <p className="text-sm text-slate-500">
                {item.title}
              </p>

              <p className="mt-3 text-3xl font-bold text-slate-800">
                {loading ? "—" : item.value}
              </p>
            </div>
          ))}
        </section>

        {/* Notifications */}
        {error && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            {error}
          </div>
        )}

        {success && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">
            {success}
          </div>
        )}

        {/* Create Assessment */}
        <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-slate-800">
              Create New Assessment
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Enter the assessment details and submission deadline.
            </p>
          </div>

          <form
            onSubmit={handleSubmit}
            className="grid gap-5 md:grid-cols-3"
          >
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Assessment Title
              </label>

              <input
                type="text"
                required
                value={form.title}
                onChange={(e) =>
                  setForm({ ...form, title: e.target.value })
                }
                placeholder="Business Strategy Report"
                className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Module
              </label>

              <input
                type="text"
                required
                value={form.module}
                onChange={(e) =>
                  setForm({ ...form, module: e.target.value })
                }
                placeholder="Business Management"
                className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Submission Deadline
              </label>

              <input
                type="datetime-local"
                required
                min={new Date().toISOString().slice(0, 16)}
                value={form.deadline}
                onChange={(e) =>
                  setForm({ ...form, deadline: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm outline-none focus:border-emerald-500"
              />
            </div>

            <div className="md:col-span-3">
              <button
                type="submit"
                disabled={saving}
                className="rounded-lg bg-emerald-600 px-6 py-3 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
              >
                {saving ? "Creating..." : "Create Assessment"}
              </button>
            </div>
          </form>
        </section>

        {/* Assessment Records */}
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-6">
            <div>
              <h2 className="font-semibold text-slate-800">
                Assessment Records
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                All assessments stored in the database.
              </p>
            </div>

            <button
              onClick={loadAssessments}
              disabled={loading}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm hover:bg-slate-50 disabled:opacity-50"
            >
              {loading ? "Loading..." : "Refresh"}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-5 py-4">Assessment</th>
                  <th className="px-5 py-4">Module</th>
                  <th className="px-5 py-4">Deadline</th>
                  <th className="px-5 py-4">Submissions</th>
                  <th className="px-5 py-4">Status</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td colSpan={5} className="px-5 py-12 text-center text-slate-500">
                      Loading assessments...
                    </td>
                  </tr>
                ) : assessments.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-5 py-12 text-center text-slate-500">
                      No assessments found.
                    </td>
                  </tr>
                ) : (
                  assessments.map((assessment) => {
                    const isOpen =
                      new Date(assessment.deadline) >= new Date();

                    return (
                      <tr
                        key={assessment.id}
                        className="hover:bg-slate-50"
                      >
                        <td className="px-5 py-4 font-medium text-slate-800">
                          {assessment.title}
                        </td>

                        <td className="px-5 py-4 text-slate-600">
                          {assessment.module}
                        </td>

                        <td className="px-5 py-4 text-slate-600">
                          {formatDate(assessment.deadline)}
                        </td>

                        <td className="px-5 py-4 text-slate-600">
                          {assessment._count?.submissions ?? 0}
                        </td>

                        <td className="px-5 py-4">
                          <span
                            className={`rounded-full px-3 py-1 text-xs font-semibold ${
                              isOpen
                                ? "bg-emerald-50 text-emerald-700"
                                : "bg-slate-100 text-slate-600"
                            }`}
                          >
                            {isOpen ? "Open" : "Deadline Passed"}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </section>

        <footer className="border-t border-slate-200 pt-5 text-xs text-slate-400">
          PEN Global · Student Management System · Assessment Module
        </footer>

      </div>
    </main>
  );
}
