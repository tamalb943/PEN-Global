
"use client";

import { useEffect, useState } from "react";

type Payment = {
  id: string;
  amount: number | string;
  paymentDate: string;
  referenceNumber: string;
};

type FeeRecord = {
  id: string;
  totalAmount: number | string;
  totalPaid: number | string;
  balance: number | string;
  dueDate: string;
  status: "PAID" | "PARTIAL" | "UNPAID";
  isOverdue: boolean;
  student: {
    studentId: string;
    fullName: string;
    email: string;
  };
  payments: Payment[];
};

export default function FeesPage() {
  const [fees, setFees] = useState<FeeRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [selectedFee, setSelectedFee] = useState<FeeRecord | null>(null);

  const [form, setForm] = useState({
    amount: "",
    referenceNumber: "",
    paymentDate: "",
  });

  const formatCurrency = (value: number | string) =>
    new Intl.NumberFormat("en-BD", {
      style: "currency",
      currency: "BDT",
      maximumFractionDigits: 2,
    }).format(Number(value));

  async function loadFees() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/fees", {
        cache: "no-store",
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(
          result.message || "Unable to retrieve fee records."
        );
      }

      setFees(result.data);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Unable to load fees."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadFees();
  }, []);

  const totalFees = fees.reduce(
    (sum, fee) => sum + Number(fee.totalAmount),
    0
  );

  const totalPaid = fees.reduce(
    (sum, fee) => sum + Number(fee.totalPaid),
    0
  );

  const outstanding = fees.reduce(
    (sum, fee) => sum + Number(fee.balance),
    0
  );

  const overdueCount = fees.filter(
    (fee) => fee.isOverdue && Number(fee.balance) > 0
  ).length;

  async function handlePayment(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (!selectedFee) return;

    setSaving(true);
    setError("");
    setSuccess("");

    try {
      const response = await fetch("/api/fees", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          feeId: selectedFee.id,
          amount: Number(form.amount),
          referenceNumber: form.referenceNumber.trim(),
          paymentDate: form.paymentDate,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(
          result.message || "Unable to record payment."
        );
      }

      setSuccess("Payment recorded successfully.");

      setForm({
        amount: "",
        referenceNumber: "",
        paymentDate: new Date().toISOString().split("T")[0],
      });

      setSelectedFee(null);

      await loadFees();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Payment failed."
      );
    } finally {
      setSaving(false);
    }
  }

  function statusStyle(status: string) {
    if (status === "PAID") {
      return "bg-emerald-50 text-emerald-700";
    }

    if (status === "PARTIAL") {
      return "bg-amber-50 text-amber-700";
    }

    return "bg-red-50 text-red-700";
  }

  return (
    <main className="min-h-screen bg-slate-50 p-6 md:p-10">
      <div className="mx-auto max-w-7xl space-y-8">

        {/* Header */}
        <header>
          <p className="text-sm font-medium text-emerald-700">
            Registry Management
          </p>

          <h1 className="mt-2 text-3xl font-bold text-slate-800">
            Fees & Payments
          </h1>

          <p className="mt-2 text-slate-500">
            Monitor tuition fees, record transactions and track outstanding balances.
          </p>
        </header>

        {/* Statistics */}
        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[
            {
              title: "Total Fees",
              value: formatCurrency(totalFees),
            },
            {
              title: "Total Collected",
              value: formatCurrency(totalPaid),
            },
            {
              title: "Outstanding Balance",
              value: formatCurrency(outstanding),
            },
            {
              title: "Overdue Accounts",
              value: loading ? "—" : String(overdueCount),
            },
          ].map((item) => (
            <div
              key={item.title}
              className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
            >
              <p className="text-sm text-slate-500">
                {item.title}
              </p>

              <p className="mt-3 text-2xl font-bold text-slate-800">
                {loading ? "—" : item.value}
              </p>
            </div>
          ))}
        </section>

        {/* Messages */}
        {error && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            {error}
          </div>
        )}

        {success && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">
            {success}
          </div>
        )}

        {/* Record Payment Form */}
        {selectedFee && (
          <section className="rounded-xl border border-emerald-200 bg-white p-6 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h2 className="text-lg font-semibold text-slate-800">
                  Record a Payment
                </h2>

                <p className="mt-1 text-sm text-slate-500">
                  {selectedFee.student.fullName} · {selectedFee.student.studentId}
                </p>

                <p className="mt-2 text-sm font-medium text-slate-700">
                  Outstanding: {formatCurrency(selectedFee.balance)}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedFee(null)}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
            </div>

            <form
              onSubmit={handlePayment}
              className="mt-6 grid gap-5 md:grid-cols-3"
            >
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">
                  Payment Amount (BDT)
                </label>

                <input
                  type="number"
                  required
                  min="0.01"
                  max={Number(selectedFee.balance)}
                  step="0.01"
                  value={form.amount}
                  onChange={(e) =>
                    setForm({ ...form, amount: e.target.value })
                  }
                  placeholder="50000"
                  className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm text-black outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">
                  Transaction Reference
                </label>

                <input
                  type="text"
                  required
                  value={form.referenceNumber}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      referenceNumber: e.target.value,
                    })
                  }
                  placeholder="TXN-2026-001"
                  className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm text-black outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">
                  Payment Date
                </label>

                <input
                  type="date"
                  required
                  value={form.paymentDate}
                  onChange={(e) =>
                    setForm({ ...form, paymentDate: e.target.value })
                  }
                  className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm text-black outline-none focus:border-emerald-500"
                />
              </div>

              <div className="md:col-span-3">
                <button
                  type="submit"
                  disabled={saving}
                  className="rounded-lg bg-emerald-600 px-6 py-3 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
                >
                  {saving ? "Recording Payment..." : "Confirm Payment"}
                </button>
              </div>
            </form>
          </section>
        )}

        {/* Fee Records */}
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-6">
            <div>
              <h2 className="font-semibold text-slate-800">
                Student Fee Records
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                {fees.length} fee records
              </p>
            </div>

            <button
              onClick={loadFees}
              disabled={loading}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-black hover:bg-slate-50 disabled:opacity-50"
            >
              {loading ? "Refreshing..." : "Refresh"}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-5 py-4">Student</th>
                  <th className="px-5 py-4">Student ID</th>
                  <th className="px-5 py-4">Total Fee</th>
                  <th className="px-5 py-4">Paid</th>
                  <th className="px-5 py-4">Balance</th>
                  <th className="px-5 py-4">Due Date</th>
                  <th className="px-5 py-4">Status</th>
                  <th className="px-5 py-4">Action</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td colSpan={8} className="px-5 py-12 text-center text-slate-500">
                      Loading fee records...
                    </td>
                  </tr>
                ) : fees.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-5 py-12 text-center text-slate-500">
                      No fee records found.
                    </td>
                  </tr>
                ) : (
                  fees.map((fee) => (
                    <tr key={fee.id} className="hover:bg-slate-50">
                      <td className="px-5 py-4 font-medium text-slate-800">
                        {fee.student.fullName}
                        <p className="mt-1 text-xs font-normal text-slate-400">
                          {fee.student.email}
                        </p>
                      </td>

                      <td className="px-5 py-4 text-slate-600">
                        {fee.student.studentId}
                      </td>

                      <td className="px-5 py-4 text-slate-700">
                        {formatCurrency(fee.totalAmount)}
                      </td>

                      <td className="px-5 py-4 text-emerald-700">
                        {formatCurrency(fee.totalPaid)}
                      </td>

                      <td className="px-5 py-4 font-semibold text-slate-800">
                        {formatCurrency(fee.balance)}
                      </td>

                      <td className="px-5 py-4 text-slate-600">
                        {new Date(fee.dueDate).toLocaleDateString("en-GB")}
                      </td>

                      <td className="px-5 py-4">
                        <div className="flex flex-col items-start gap-1">
                          <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${statusStyle(fee.status)}`}>
                            {fee.status}
                          </span>

                          {fee.isOverdue && Number(fee.balance) > 0 && (
                            <span className="text-xs font-medium text-red-600">
                              Overdue
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="px-5 py-4">
                        {Number(fee.balance) > 0 ? (
                          <button
                            onClick={() => {
                              setSelectedFee(fee);
                              setError("");
                              setSuccess("");
                            }}
                            className="whitespace-nowrap rounded-lg bg-emerald-600 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-700"
                          >
                            Record Payment
                          </button>
                        ) : (
                          <span className="text-xs font-medium text-emerald-700">
                            Fully Paid
                          </span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* Payment History */}
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="border-b border-slate-200 p-6">
            <h2 className="font-semibold text-slate-800">
              Recent Payment Transactions
            </h2>

            <p className="mt-1 text-sm text-slate-500">
              Payment history across registered students.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-5 py-4">Student</th>
                  <th className="px-5 py-4">Reference</th>
                  <th className="px-5 py-4">Payment Date</th>
                  <th className="px-5 py-4">Amount</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100">
                {fees.flatMap((fee) =>
                  fee.payments.map((payment) => ({
                    ...payment,
                    studentName: fee.student.fullName,
                  }))
                ).length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-5 py-10 text-center text-slate-500">
                      No payment transactions recorded yet.
                    </td>
                  </tr>
                ) : (
                  fees
                    .flatMap((fee) =>
                      fee.payments.map((payment) => ({
                        ...payment,
                        studentName: fee.student.fullName,
                      }))
                    )
                    .sort(
                      (a, b) =>
                        new Date(b.paymentDate).getTime() -
                        new Date(a.paymentDate).getTime()
                    )
                    .map((payment) => (
                      <tr key={payment.id}>
                        <td className="px-5 py-4 font-medium text-slate-800">
                          {payment.studentName}
                        </td>

                        <td className="px-5 py-4 text-slate-600">
                          {payment.referenceNumber}
                        </td>

                        <td className="px-5 py-4 text-slate-600">
                          {new Date(payment.paymentDate).toLocaleDateString("en-GB")}
                        </td>

                        <td className="px-5 py-4 font-semibold text-emerald-700">
                          {formatCurrency(payment.amount)}
                        </td>
                      </tr>
                    ))
                )}
              </tbody>
            </table>
          </div>
        </section>

        <footer className="border-t border-slate-200 pt-5 text-xs text-slate-400">
          PEN Global · Student Management System · Finance Module
        </footer>
      </div>
    </main>
  );
}
