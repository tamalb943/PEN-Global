
"use client";

import { useEffect, useState } from "react";

type Student = {
  id: string;
  studentId: string;
  fullName: string;
};

type Assessment = {
  id: string;
  title: string;
  module: string;
};

type Grade = {
  id: string;
  studentId: string;
  assessmentId: string;
  score: number;
  isPublished: boolean;
  student: {
    studentId: string;
    fullName: string;
  };
  assessment: {
    title: string;
    module: string;
  };
};

function classification(score: number) {
  if (score >= 70) return "Distinction";
  if (score >= 60) return "Merit";
  if (score >= 40) return "Pass";
  return "Fail";
}

export default function MarksheetsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);

  const [studentId, setStudentId] = useState("");
  const [assessmentId, setAssessmentId] = useState("");
  const [score, setScore] = useState("");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  async function loadData() {
    try {
      setLoading(true);
      setError("");

      const [studentResponse, assessmentResponse, gradeResponse] =
        await Promise.all([
          fetch("/api/students", { cache: "no-store" }),
          fetch("/api/assessments", { cache: "no-store" }),
          fetch("/api/grades", { cache: "no-store" }),
        ]);

      const [studentResult, assessmentResult, gradeResult] =
        await Promise.all([
          studentResponse.json(),
          assessmentResponse.json(),
          gradeResponse.json(),
        ]);

      if (
        !studentResponse.ok ||
        !assessmentResponse.ok ||
        !gradeResponse.ok ||
        !studentResult.success ||
        !assessmentResult.success ||
        !gradeResult.success
      ) {
        throw new Error("Failed to load marksheet data.");
      }

      setStudents(studentResult.data);
      setAssessments(assessmentResult.data);
      setGrades(gradeResult.data);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Unable to load data."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  async function saveGrade(
    e: React.FormEvent<HTMLFormElement>
  ) {
    e.preventDefault();

    const numericScore = Number(score);

    if (
      !studentId ||
      !assessmentId ||
      !Number.isInteger(numericScore) ||
      numericScore < 0 ||
      numericScore > 100
    ) {
      setError("Select a student, assessment, and valid score from 0 to 100.");
      return;
    }

    try {
      setSaving(true);
      setError("");
      setSuccess("");

      const response = await fetch("/api/grades", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          studentId,
          assessmentId,
          score: numericScore,
          isPublished: false,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || "Failed to save grade.");
      }

      setSuccess("Grade saved successfully. It is currently unpublished.");
      setScore("");

      await loadData();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Unable to save grade."
      );
    } finally {
      setSaving(false);
    }
  }

  async function togglePublication(grade: Grade) {
    try {
      setError("");
      setSuccess("");

      const response = await fetch("/api/grades", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          studentId: grade.studentId,
          assessmentId: grade.assessmentId,
          score: grade.score,
          isPublished: !grade.isPublished,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || "Unable to update publication.");
      }

      setSuccess(
        grade.isPublished
          ? "Result withheld successfully."
          : "Result published successfully."
      );

      await loadData();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Unable to update result."
      );
    }
  }

  const publishedCount = grades.filter(
    (grade) => grade.isPublished
  ).length;

  const unpublishedCount = grades.length - publishedCount;

  return (
    <main className="min-h-screen bg-slate-50 p-6 md:p-10">
      <div className="mx-auto max-w-7xl space-y-8">

        {/* Header */}
        <header>
          <p className="text-sm font-medium text-emerald-700">
            Registry Management
          </p>

          <h1 className="mt-2 text-3xl font-bold text-slate-800">
            Marksheets & Results
          </h1>

          <p className="mt-2 text-slate-500">
            Record student grades, calculate classifications, and manage result publication.
          </p>
        </header>

        {/* Statistics */}
        <section className="grid gap-4 sm:grid-cols-3">
          {[
            { title: "Total Results", value: grades.length },
            { title: "Published Results", value: publishedCount },
            { title: "Unpublished Results", value: unpublishedCount },
          ].map((item) => (
            <div
              key={item.title}
              className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
            >
              <p className="text-sm text-slate-500">{item.title}</p>
              <p className="mt-3 text-3xl font-bold text-slate-800">
                {loading ? "—" : item.value}
              </p>
            </div>
          ))}
        </section>

        {/* Messages */}
        {error && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            {error}
          </div>
        )}

        {success && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">
            {success}
          </div>
        )}

        {/* Grade Entry */}
        <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-800">
            Enter Student Grade
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Select a student and assessment, then enter a score out of 100.
          </p>

          <form
            onSubmit={saveGrade}
            className="mt-6 grid gap-5 md:grid-cols-3"
          >
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Student
              </label>

              <select
                required
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-4 py-3 text-sm"
              >
                <option value="">Select student</option>
                {students.map((student) => (
                  <option key={student.id} value={student.id}>
                    {student.studentId} — {student.fullName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Assessment
              </label>

              <select
                required
                value={assessmentId}
                onChange={(e) => setAssessmentId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-4 py-3 text-sm"
              >
                <option value="">Select assessment</option>
                {assessments.map((assessment) => (
                  <option key={assessment.id} value={assessment.id}>
                    {assessment.title} — {assessment.module}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Score (0–100)
              </label>

              <input
                type="number"
                min="0"
                max="100"
                step="1"
                required
                value={score}
                onChange={(e) => setScore(e.target.value)}
                placeholder="Enter marks"
                className="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm"
              />
            </div>

            {score !== "" &&
              Number.isInteger(Number(score)) &&
              Number(score) >= 0 &&
              Number(score) <= 100 && (
                <div className="md:col-span-3 rounded-lg bg-slate-50 p-4 text-sm text-slate-700">
                  Classification:{" "}
                  <strong>{classification(Number(score))}</strong>
                  <span className="ml-2 text-slate-500">
                    (Results are saved as unpublished by default.)
                  </span>
                </div>
              )}

            <div className="md:col-span-3">
              <button
                type="submit"
                disabled={saving || loading}
                className="rounded-lg bg-emerald-600 px-6 py-3 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
              >
                {saving ? "Saving..." : "Save Grade"}
              </button>
            </div>
          </form>
        </section>

        {/* Results Table */}
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-6">
            <div>
              <h2 className="font-semibold text-slate-800">
                Student Results
              </h2>
              <p className="mt-1 text-sm text-slate-500">
                Review grades and control publication status.
              </p>
            </div>

            <button
              onClick={loadData}
              disabled={loading}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-black hover:bg-slate-50"
            >
              {loading ? "Loading..." : "Refresh"}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase text-slate-500">
                <tr>
                  <th className="px-5 py-4">Student</th>
                  <th className="px-5 py-4">Assessment</th>
                  <th className="px-5 py-4">Module</th>
                  <th className="px-5 py-4">Score</th>
                  <th className="px-5 py-4">Classification</th>
                  <th className="px-5 py-4">Publication</th>
                  <th className="px-5 py-4">Action</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td colSpan={7} className="px-5 py-12 text-center text-slate-500">
                      Loading results...
                    </td>
                  </tr>
                ) : grades.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-5 py-12 text-center text-slate-500">
                      No grades recorded yet.
                    </td>
                  </tr>
                ) : (
                  grades.map((grade) => (
                    <tr key={grade.id} className="hover:bg-slate-50">
                      <td className="px-5 py-4">
                        <p className="font-medium text-slate-800">
                          {grade.student.fullName}
                        </p>
                        <p className="text-xs text-slate-500">
                          {grade.student.studentId}
                        </p>
                      </td>

                      <td className="px-5 py-4 text-slate-700">
                        {grade.assessment.title}
                      </td>

                      <td className="px-5 py-4 text-slate-600">
                        {grade.assessment.module}
                      </td>

                      <td className="px-5 py-4 font-semibold text-slate-800">
                        {grade.score}/100
                      </td>

                      <td className="px-5 py-4 text-slate-700">
                        {classification(grade.score)}
                      </td>

                      <td className="px-5 py-4">
                        <span
                          className={`rounded-full px-3 py-1 text-xs font-semibold ${
                            grade.isPublished
                              ? "bg-emerald-50 text-emerald-700"
                              : "bg-amber-50 text-amber-700"
                          }`}
                        >
                          {grade.isPublished ? "Published" : "Withheld"}
                        </span>
                      </td>

                      <td className="px-5 py-4">
                        <button
                          onClick={() => togglePublication(grade)}
                          className="whitespace-nowrap rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-black hover:bg-slate-100"
                        >
                          {grade.isPublished ? "Withhold" : "Publish"}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* Classification Guide */}
        <section className="rounded-xl border border-slate-200 bg-white p-6">
          <h2 className="font-semibold text-slate-800">
            Classification Guide
          </h2>

          <div className="mt-4 grid gap-3 sm:grid-cols-4">
            {[
              { label: "Distinction", range: "70–100" },
              { label: "Merit", range: "60–69" },
              { label: "Pass", range: "40–59" },
              { label: "Fail", range: "0–39" },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-lg bg-slate-50 p-4"
              >
                <p className="font-semibold text-slate-800">
                  {item.label}
                </p>
                <p className="mt-1 text-sm text-slate-500">
                  {item.range} marks
                </p>
              </div>
            ))}
          </div>
        </section>

        <footer className="border-t border-slate-200 pt-5 text-xs text-slate-400">
          PEN Global · Student Management System · Academic Results Module
        </footer>
      </div>
    </main>
  );
}
