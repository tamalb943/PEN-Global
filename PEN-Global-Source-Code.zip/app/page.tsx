
"use client";

import { useEffect, useState } from "react";

type Student = {
  id: string;
  studentId: string;
  fullName: string;
  programme?: { name: string };
  enrolmentStatus: string;
};

type Fee = {
  balance: number | string;
  isOverdue: boolean;
};

type DashboardData = {
  students: Student[];
  fees: Fee[];
  submissions: unknown[];
};

const navigation = [
  { label: "Overview", href: "/", icon: "◫" },
  { label: "Students", href: "/students", icon: "♙" },
  { label: "Programmes", href: "/programmes", icon: "▤" },
  { label: "Fees & Payments", href: "/fees", icon: "£" },
  { label: "Assessments", href: "/assessments", icon: "▣" },
  { label: "Marksheets & Results", href: "/marksheets", icon: "▥" },
];

async function getData(url: string) {
  const response = await fetch(url, { cache: "no-store" });

  if (!response.ok) {
    throw new Error(`Failed to load ${url}`);
  }

  const result = await response.json();

  if (result.success === false) {
    throw new Error(result.error || `Failed to load ${url}`);
  }

  return result.data ?? [];
}

export default function Home() {
  const [data, setData] = useState<DashboardData>({
    students: [],
    fees: [],
    submissions: [],
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadDashboard() {
      try {
        const [students, fees, submissions] = await Promise.all([
          getData("/api/students"),
          getData("/api/fees"),
          getData("/api/submissions"),
        ]);

        setData({ students, fees, submissions });
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Unable to load dashboard"
        );
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, []);

  const totalStudents = data.students.length;

  const enrolledStudents = data.students.filter(
    (student) => student.enrolmentStatus === "ENROLLED"
  ).length;

  const outstandingFees = data.fees.reduce(
    (total, fee) => total + Number(fee.balance || 0),
    0
  );

  const totalSubmissions = data.submissions.length;

  const stats = [
    {
      title: "Total Students",
      value: totalStudents,
      description: "Registered student records",
    },
    {
      title: "Enrolled Students",
      value: enrolledStudents,
      description: "Currently enrolled",
    },
    {
      title: "Outstanding Fees",
      value: `৳${outstandingFees.toLocaleString("en-BD")}`,
      description: `${data.fees.filter((fee) => fee.isOverdue).length} overdue fee records`,
    },
    {
      title: "Recorded Submissions",
      value: totalSubmissions,
      description: "Assignment submissions received",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 md:flex">
      <aside className="w-full bg-slate-900 text-white md:min-h-screen md:w-64 md:shrink-0">
        <div className="border-b border-slate-700 p-6">
          <h1 className="text-xl font-bold tracking-wide">
            PEN <span className="text-emerald-400">GLOBAL</span>
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Student Management System
          </p>
        </div>

        <nav className="space-y-2 p-4">
          <p className="mb-4 px-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
            Registry Management
          </p>

          {navigation.map((item, index) => (
            <a
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-3 text-sm ${
                index === 0
                  ? "bg-emerald-600 text-white"
                  : "text-slate-300 hover:bg-slate-800"
              }`}
            >
              <span className="w-5 text-center">{item.icon}</span>
              {item.label}
            </a>
          ))}
        </nav>

        <div className="mt-8 border-t border-slate-700 p-5">
          <p className="text-sm font-medium">Staff Portal</p>
          <p className="mt-1 text-xs text-slate-400">
            Registry Administrator
          </p>
        </div>
      </aside>

      <main className="min-w-0 flex-1">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 bg-white px-6 py-5">
          <div>
            <h2 className="text-xl font-bold">Registry Overview</h2>
            <p className="mt-1 text-sm text-slate-500">
              Student administration dashboard
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="rounded-full bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-700">
              Staff View
            </span>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-200 font-semibold">
              RA
            </div>
          </div>
        </header>

        <div className="space-y-6 p-6">
          <div>
            <h3 className="text-lg font-semibold">
              Welcome to Registry Management
            </h3>
            <p className="mt-1 text-sm text-slate-500">
              Manage student records, fees, assessments and academic results.
            </p>
          </div>

          {error && (
            <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
              Dashboard data could not be fully loaded: {error}
              <button
                onClick={() => window.location.reload()}
                className="ml-2 font-semibold underline"
              >
                Retry
              </button>
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {stats.map((stat) => (
              <div
                key={stat.title}
                className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
              >
                <p className="text-sm text-slate-500">{stat.title}</p>
                <p className="mt-3 text-3xl font-bold text-slate-800">
                  {loading ? "—" : stat.value}
                </p>
                <p className="mt-2 text-xs text-slate-400">
                  {loading ? "Loading database..." : stat.description}
                </p>
              </div>
            ))}
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <section className="rounded-xl border border-slate-200 bg-white p-6 lg:col-span-2">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Student Records</h3>
                <a
                  href="/students"
                  className="text-sm text-emerald-700 hover:underline"
                >
                  View all
                </a>
              </div>

              <div className="mt-5 overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 text-slate-500">
                    <tr>
                      <th className="py-3">Student</th>
                      <th className="py-3">Student ID</th>
                      <th className="py-3">Programme</th>
                      <th className="py-3">Status</th>
                    </tr>
                  </thead>

                  <tbody>
                    {!loading && data.students.length === 0 && (
                      <tr>
                        <td colSpan={4} className="py-10 text-center text-slate-400">
                          No student records found.
                        </td>
                      </tr>
                    )}

                    {data.students.slice(0, 5).map((student) => (
                      <tr
                        key={student.id}
                        className="border-b border-slate-100"
                      >
                        <td className="py-4 font-medium">{student.fullName}</td>
                        <td className="py-4 text-emerald-700">
                          {student.studentId}
                        </td>
                        <td className="py-4">
                          {student.programme?.name || "Not assigned"}
                        </td>
                        <td className="py-4">{student.enrolmentStatus}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="rounded-xl border border-slate-200 bg-white p-6">
              <h3 className="font-semibold">Registry Activity</h3>
              <p className="mt-1 text-sm text-slate-500">
                Administrative overview
              </p>

              <div className="mt-6 space-y-4 text-sm">
                <div className="rounded-lg bg-slate-50 p-4">
                  <p className="font-medium">Student Registry</p>
                  <p className="mt-1 text-slate-500">
                    {loading ? "Loading..." : `${totalStudents} student records available`}
                  </p>
                </div>

                <div className="rounded-lg bg-slate-50 p-4">
                  <p className="font-medium">Fee Management</p>
                  <p className="mt-1 text-slate-500">
                    {loading ? "Loading..." : `${data.fees.length} fee records available`}
                  </p>
                </div>

                <div className="rounded-lg bg-slate-50 p-4">
                  <p className="font-medium">Assessment Submissions</p>
                  <p className="mt-1 text-slate-500">
                    {loading ? "Loading..." : `${totalSubmissions} submissions recorded`}
                  </p>
                </div>
              </div>
            </section>
          </div>

          <footer className="border-t border-slate-200 pt-5 text-xs text-slate-400">
            PEN Global · Student Management System · Registry Module
          </footer>
        </div>
      </main>
    </div>
  );
}
