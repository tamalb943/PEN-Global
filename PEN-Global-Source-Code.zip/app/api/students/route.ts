
import { NextRequest } from "next/server";
import { prisma } from "../../lib/prisma";

const validStatuses = [
  "ENROLLED",
  "DEFERRED",
  "WITHDRAWN",
  "COMPLETED",
] as const;

// GET: Retrieve all students

// GET: Retrieve, search and filter students
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    const search = searchParams.get("search")?.trim();
    const programmeId = searchParams.get("programmeId");
    const status = searchParams.get("status");

    const where = {
      ...(search
        ? {
            OR: [
              {
                fullName: {
                  contains: search,
                  mode: "insensitive" as const,
                },
              },
              {
                studentId: {
                  contains: search,
                  mode: "insensitive" as const,
                },
              },
            ],
          }
        : {}),
      ...(programmeId ? { programmeId } : {}),
      ...(status && validStatuses.includes(
        status as (typeof validStatuses)[number]
      )
        ? { enrolmentStatus: status as (typeof validStatuses)[number] }
        : {}),
    };

    const students = await prisma.student.findMany({
      where,
      include: {
        programme: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    return Response.json({
      success: true,
      count: students.length,
      data: students,
    });
  } catch (error) {
    console.error("Student retrieval failed:", error);

    return Response.json(
      { success: false, message: "Failed to retrieve students" },
      { status: 500 }
    );
  }
}


// POST: Register a new student
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const {
      fullName,
      email,
      dateOfBirth,
      programmeId,
      academicYear,
      enrolmentStatus,
    } = body;

    // Validate required fields
    if (
      typeof fullName !== "string" ||
      !fullName.trim() ||
      typeof email !== "string" ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) ||
      typeof dateOfBirth !== "string" ||
      !dateOfBirth ||
      typeof programmeId !== "string" ||
      !programmeId.trim() ||
      typeof academicYear !== "string" ||
      !academicYear.trim()
    ) {
      return Response.json(
        { success: false, message: "Invalid or missing student details" },
        { status: 400 }
      );
    }

    // Validate date of birth
    const dob = new Date(dateOfBirth);

    if (
      Number.isNaN(dob.getTime()) ||
      dob.toISOString().slice(0, 10) !== dateOfBirth ||
      dob >= new Date()
    ) {
      return Response.json(
        { success: false, message: "Invalid date of birth" },
        { status: 400 }
      );
    }

    // Validate enrolment status
    const status = enrolmentStatus ?? "ENROLLED";

    if (
      typeof status !== "string" ||
      !validStatuses.includes(status as (typeof validStatuses)[number])
    ) {
      return Response.json(
        { success: false, message: "Invalid enrolment status" },
        { status: 400 }
      );
    }

    const normalizedEmail = email.trim().toLowerCase();

    // Generate Student ID and create student atomically
    const student = await prisma.$transaction(async (tx) => {
      const programme = await tx.programme.findUnique({
        where: { id: programmeId },
      });

      if (!programme) {
        throw new Error("PROGRAMME_NOT_FOUND");
      }

      const year = new Date().getFullYear();

      const counter = await tx.studentIdCounter.upsert({
        where: { year },
        create: {
          year,
          lastNumber: 1,
        },
        update: {
          lastNumber: {
            increment: 1,
          },
        },
      });

      const studentId = `SMS-${year}-${String(
        counter.lastNumber
      ).padStart(4, "0")}`;

      return tx.student.create({
        data: {
          studentId,
          fullName: fullName.trim(),
          email: normalizedEmail,
          dateOfBirth: dob,
          academicYear: academicYear.trim(),
          enrolmentStatus: status as (typeof validStatuses)[number],
          programmeId,
        },
        include: {
          programme: true,
        },
      });
    });

    return Response.json(
      {
        success: true,
        message: "Student enrolled successfully",
        data: student,
      },
      { status: 201 }
    );
  } catch (error: unknown) {
    if (error instanceof Error && error.message === "PROGRAMME_NOT_FOUND") {
      return Response.json(
        { success: false, message: "Programme not found" },
        { status: 404 }
      );
    }

    if (
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      error.code === "P2002"
    ) {
      return Response.json(
        { success: false, message: "Student email already exists" },
        { status: 409 }
      );
    }

    console.error("Student enrolment failed:", error);

    return Response.json(
      { success: false, message: "Student enrolment failed" },
      { status: 500 }
    );
  }
}
