
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "../../lib/prisma";

// GET: Retrieve fees and calculate outstanding balances
export async function GET() {
  try {
    const fees = await prisma.fee.findMany({
      include: {
        student: {
          select: {
            studentId: true,
            fullName: true,
            email: true,
          },
        },
        payments: true,
      },
      orderBy: { dueDate: "asc" },
    });

    const data = fees.map((fee) => {
      const totalPaid = fee.payments.reduce(
        (sum, payment) => sum + Number(payment.amount),
        0
      );

      const totalAmount = Number(fee.totalAmount);
      const balance = Math.max(totalAmount - totalPaid, 0);

      let status = "UNPAID";
      if (balance === 0) status = "PAID";
      else if (totalPaid > 0) status = "PARTIAL";

      return {
        id: fee.id,
        student: fee.student,
        totalAmount,
        totalPaid,
        balance,
        dueDate: fee.dueDate,
        status,
        isOverdue: balance > 0 && new Date(fee.dueDate) < new Date(),
        payments: fee.payments,
      };
    });

    return NextResponse.json({ success: true, data });
  } catch (error) {
    console.error("Fees retrieval failed:", error);
    return NextResponse.json(
      { success: false, message: "Unable to retrieve fees" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const { feeId, amount, referenceNumber, paymentDate } = body;

    if (
      !feeId ||
      !referenceNumber?.trim() ||
      !Number.isFinite(Number(amount)) ||
      Number(amount) <= 0
    ) {
      return NextResponse.json(
        { success: false, message: "Invalid payment details" },
        { status: 400 }
      );
    }
    
const existingPayment = await prisma.payment.findUnique({
  where: {
    referenceNumber: referenceNumber.trim(),
  },
});

if (existingPayment) {
  return NextResponse.json(
    { success: false, message: "Payment reference already exists" },
    { status: 409 }
  );
}
    const fee = await prisma.fee.findUnique({
      where: { id: feeId },
      include: { payments: true },
    });

    if (!fee) {
      return NextResponse.json(
        { success: false, message: "Fee record not found" },
        { status: 404 }
      );
    }

    const totalPaid = fee.payments.reduce(
      (sum, payment) => sum + Number(payment.amount),
      0
    );

    const balance = Number(fee.totalAmount) - totalPaid;
    const paymentAmount = Number(amount);

    if (paymentAmount > balance) {
      return NextResponse.json(
        { success: false, message: "Payment exceeds outstanding balance" },
        { status: 400 }
      );
    }

    const result = await prisma.$transaction(async (tx) => {
      const payment = await tx.payment.create({
        data: {
          feeId,
          amount: paymentAmount,
          referenceNumber: referenceNumber.trim(),
          paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
        },
      });

      const newTotalPaid = totalPaid + paymentAmount;
      const newBalance = Number(fee.totalAmount) - newTotalPaid;

      const status =
        newBalance <= 0
          ? "PAID"
          : newTotalPaid > 0
          ? "PARTIAL"
          : "UNPAID";

      const updatedFee = await tx.fee.update({
        where: { id: feeId },
        data: { status },
      });

      return { payment, updatedFee, newBalance };
    });

    return NextResponse.json({
      success: true,
      message: "Payment recorded successfully",
      data: result,
    });
  } catch (error) {
    console.error("Payment recording failed:", error);

    return NextResponse.json(
      { success: false, message: "Unable to record payment" },
      { status: 500 }
    );
  }
}
