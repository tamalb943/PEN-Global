
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "../../lib/prisma";

// GET: Retrieve submissions
export async function GET(request: NextRequest) {
  try {
    const studentId = request.nextUrl.searchParams.get("studentId");

    const submissions = await prisma.submission.findMany({
      where: studentId ? { studentId } : {},
      include: {
        student: true,
        assessment: true,
      },
      orderBy: { submittedAt: "desc" },
    });

    return NextResponse.json({ success: true, data: submissions });
  } catch (error) {
    console.error("Submission retrieval error:", error);
    return NextResponse.json(
      { success: false, message: "Could not retrieve submissions" },
      { status: 500 }
    );
  }
}

// POST: Create or resubmit an assignment
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { studentId, assessmentId, fileName, fileUrl } = body;

    if (!studentId || !assessmentId || !fileName || !fileUrl) {
      return NextResponse.json(
        { success: false, message: "All submission details are required" },
        { status: 400 }
      );
    }

    const student = await prisma.student.findFirst({
  where: {
    OR: [
      { id: studentId },
      { studentId: studentId },
    ],
  },
});

    if (!student) {
      return NextResponse.json(
        { success: false, message: "Student not found" },
        { status: 404 }
      );
    }

    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
    });

    if (!assessment) {
      return NextResponse.json(
        { success: false, message: "Assessment not found" },
        { status: 404 }
      );
    }

    const isLate = new Date() > new Date(assessment.deadline);

    const existingSubmission = await prisma.submission.findUnique({
      where: {
        studentId_assessmentId: {
  studentId: student.id,
  assessmentId,
}
      },
    });

    let submission;

    if (existingSubmission) {
      submission = await prisma.submission.update({
        where: { id: existingSubmission.id },
        data: {
          fileName,
          fileUrl,
          submittedAt: new Date(),
          isLate,
          resubmissionCount: { increment: 1 },
        },
      });
    } else {
      submission = await prisma.submission.create({
        data: {
          studentId: student.id,
          assessmentId,
          fileName,
          fileUrl,
          isLate,
        },
      });
    }

    return NextResponse.json({
      success: true,
      message: existingSubmission
        ? "Submission updated successfully"
        : "Submission created successfully",
      data: submission,
    });
  } catch (error) {
    console.error("Submission error:", error);
    return NextResponse.json(
      { success: false, message: "Could not process submission" },
      { status: 500 }
    );
  }
}
