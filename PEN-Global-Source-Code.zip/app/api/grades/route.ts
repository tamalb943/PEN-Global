
import { prisma } from "../../lib/prisma";
import { NextRequest } from "next/server";

// GET: Retrieve grades, with an option to show published results only
export async function GET(request: NextRequest) {
  try {
    const publishedOnly =
      request.nextUrl.searchParams.get("publishedOnly") === "true";

    const grades = await prisma.grade.findMany({
      where: publishedOnly ? { isPublished: true } : {},
      include: {
        student: {
          select: {
            studentId: true,
            fullName: true,
            email: true,
          },
        },
        assessment: {
          select: {
            title: true,
            module: true,
            deadline: true,
          },
        },
      },
      orderBy: {
        updatedAt: "desc",
      },
    });

    return Response.json({
      success: true,
      data: grades,
    });
  } catch (error) {
    console.error("Failed to retrieve grades:", error);

    return Response.json(
      { success: false, message: "Failed to retrieve grades" },
      { status: 500 }
    );
  }
}

// POST: Create or update a student's grade
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const { studentId, assessmentId, score, isPublished } = body;

    if (
      typeof studentId !== "string" ||
      !studentId.trim() ||
      typeof assessmentId !== "string" ||
      !assessmentId.trim() ||
      !Number.isInteger(Number(score)) ||
      Number(score) < 0 ||
      Number(score) > 100
    ) {
      return Response.json(
        { success: false, message: "Invalid student, assessment, or score" },
        { status: 400 }
      );
    }

    const student = await prisma.student.findFirst({
      where: {
        OR: [
          { id: studentId },
          { studentId: studentId },
        ],
      },
    });

    if (!student) {
      return Response.json(
        { success: false, message: "Student not found" },
        { status: 404 }
      );
    }

    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
    });

    if (!assessment) {
      return Response.json(
        { success: false, message: "Assessment not found" },
        { status: 404 }
      );
    }

    const grade = await prisma.grade.upsert({
      where: {
        studentId_assessmentId: {
          studentId: student.id,
          assessmentId,
        },
      },
      update: {
        score: Number(score),
        isPublished: isPublished === true,
      },
      create: {
        studentId: student.id,
        assessmentId,
        score: Number(score),
        isPublished: isPublished === true,
      },
      include: {
        student: {
          select: {
            studentId: true,
            fullName: true,
          },
        },
        assessment: {
          select: {
            title: true,
            module: true,
          },
        },
      },
    });

    return Response.json({
      success: true,
      message: "Grade saved successfully",
      data: grade,
    });
  } catch (error) {
    console.error("Failed to save grade:", error);

    return Response.json(
      { success: false, message: "Failed to save grade" },
      { status: 500 }
    );
  }
}
