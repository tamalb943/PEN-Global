
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "../../lib/prisma";

// GET: Retrieve all assessments
export async function GET() {
  try {
    const assessments = await prisma.assessment.findMany({
      orderBy: { deadline: "asc" },
      include: {
        _count: {
          select: { submissions: true },
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: assessments,
    });
  } catch (error) {
    console.error("Assessment retrieval failed:", error);

    return NextResponse.json(
      { success: false, message: "Unable to retrieve assessments" },
      { status: 500 }
    );
  }
}

// POST: Create an assessment
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, module, deadline } = body;

    if (
      typeof title !== "string" ||
      !title.trim() ||
      typeof module !== "string" ||
      !module.trim() ||
      !deadline
    ) {
      return NextResponse.json(
        { success: false, message: "Title, module and deadline are required" },
        { status: 400 }
      );
    }

    const deadlineDate = new Date(deadline);

    if (Number.isNaN(deadlineDate.getTime())) {
      return NextResponse.json(
        { success: false, message: "Invalid deadline date" },
        { status: 400 }
      );
    }

    const assessment = await prisma.assessment.create({
      data: {
        title: title.trim(),
        module: module.trim(),
        deadline: deadlineDate,
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: "Assessment created successfully",
        data: assessment,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Assessment creation failed:", error);

    return NextResponse.json(
      { success: false, message: "Unable to create assessment" },
      { status: 500 }
    );
  }
}
