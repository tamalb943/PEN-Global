
import { prisma } from "../../lib/prisma";
import { NextRequest } from "next/server";

// GET: Retrieve all programmes
export async function GET() {
  try {
    const programmes = await prisma.programme.findMany({
      orderBy: { name: "asc" },
    });

    return Response.json({
      success: true,
      data: programmes,
    });
  } catch (error) {
    console.error("Failed to retrieve programmes:", error);

    return Response.json(
      { success: false, message: "Failed to retrieve programmes" },
      { status: 500 }
    );
  }
}

// POST: Create a new programme
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, code, feeAmount } = body;

    if (
      typeof name !== "string" ||
      !name.trim() ||
      typeof code !== "string" ||
      !code.trim() ||
      feeAmount === undefined ||
      feeAmount === null ||
      feeAmount === "" ||
      !Number.isFinite(Number(feeAmount)) ||
      Number(feeAmount) < 0
    ) {
      return Response.json(
        { success: false, message: "Invalid programme details" },
        { status: 400 }
      );
    }

    const programme = await prisma.programme.create({
      data: {
        name: name.trim(),
        code: code.trim().toUpperCase(),
        feeAmount: Number(feeAmount),
      },
    });

    return Response.json(
      {
        success: true,
        message: "Programme created successfully",
        data: programme,
      },
      { status: 201 }
    );
  } catch (error: unknown) {
    if (
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      error.code === "P2002"
    ) {
      return Response.json(
        { success: false, message: "Programme code already exists" },
        { status: 409 }
      );
    }

    console.error("Failed to create programme:", error);

    return Response.json(
      { success: false, message: "Failed to create programme" },
      { status: 500 }
    );
  }
}
